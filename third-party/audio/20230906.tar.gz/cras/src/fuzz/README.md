# OSS-Fuzz for CRAS

This directory contains source code and build scripts for coverage-guided
fuzzers.

Detailed instructions are available at: https://google.github.io/oss-fuzz/

Our configuration lives at: https://github.com/google/oss-fuzz/tree/master/projects/cras

## Local reproduction setup

Please refer to:
https://google.github.io/oss-fuzz/getting-started/new-project-guide/#prerequisites

to set up docker and other optional dependencies.
