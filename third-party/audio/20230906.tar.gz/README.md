# ChromiumOS Audio Daemon and tools

*   [Docs](docs/)
*   Google Internal Docs: [go/cros-audio](https://goto.google.com/cros-audio)
*   [Contributing](CONTRIBUTING.md)
